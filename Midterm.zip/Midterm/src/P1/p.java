/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package P1;

import java.util.Arrays;

/**
 *
 * @author user
 */
public class p {
    public static void main(String[] args) {
        p2 cis104=new p2("CIS104");
        cis104.addStudent("Khalid");
        cis104.addStudent("Haneen");
        cis104.addStudent("Abdulaziz");
        System.out.println(Arrays.toString(cis104.getStudents()));
        System.out.println(cis104.getNumberOfStudents());
        System.out.println(cis104.getCourseName());
        cis104.dropStudent("Khalid");
        System.out.println(Arrays.toString(cis104.getStudents()));
        Course math104=new Course("MATH104");        
        math104.addStudent("Dinah");
        math104.addStudent("Abdullah");
        math104.addStudent("Raghad");
        System.out.println(math104.getNumberOfStudents());
        System.out.println(math104.getCourseName());
         System.out.println(Arrays.toString(math104.getStudents()));
        
    }
    
}

