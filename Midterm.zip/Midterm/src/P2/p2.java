/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package P2;

/**
 *
 * @author user
 */
import P1.TestP;
import java.util.*;
import java.util.Arrays;
public class p2 {
    private String courseName;
    private String[] students=new String[100];
    private int numberOfStudents;
    private Date date=new Date();
    public p2(String courseName){
        
    }

    public String getCourseName() {
        return courseName;
    }

    public String[] getStudents() {
        return students;
    }

    public int getNumberOfStudents() {
        return numberOfStudents;
    }
    public void addStudent(String student){
        this.students[students.length]=student;
        numberOfStudents++;
        
    }
    public void dropStudent(String student){
        int drop=-1;
        for (int i=0;i<students.length;i++){
            if(students[i].equalsIgnoreCase(student)){
                drop=i;
            }
            for (i=drop;i<students.length;i++){
                students[i]=students[i+1];
            } 
        }
        numberOfStudents--;
    
       
}

    public Date getDate() {
        return date;
    }
    public static void main(String[] args) {
        p2 cis104=new p2("CIS104");
        cis104.addStudent("Khalid");
        cis104.addStudent("Haneen");
        cis104.addStudent("Abdulaziz");
        System.out.println(Arrays.toString(cis104.getStudents()));
        System.out.println(cis104.getNumberOfStudents());
        System.out.println(cis104.getCourseName());
        cis104.dropStudent("Khalid");
        System.out.println(Arrays.toString(cis104.getStudents()));
        p2 math104=new p2("MATH104");        
        math104.addStudent("Dinah");
        math104.addStudent("Abdullah");
        math104.addStudent("Raghad");
        System.out.println(math104.getNumberOfStudents());
        System.out.println(math104.getCourseName());
         System.out.println(Arrays.toString(math104.getStudents()));
        System.out.println(cis104.getDate());
    }
}