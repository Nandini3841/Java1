/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midterm;

/**
 *
 * @author user
 */
import java.util.*;

 public class Midterm{
     int c;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //System.out.print("Enter the regex here");
        //String s=input.next();
        //System.out.println(s.matches("[\\d]{3}-[\\d]{2}-[\\d]{4}"));
        //System.out.println(s.matches("[\\d]+[0,2,4,6,8]"));
        //System.out.println(s.matches("[\\d]{4}[0,2,4,6,8]"));
        //System.out.println(s.matches("\\([\\d]{3}[1-9]\\)[\\d]{3}-[\\d]{4}"));
        //System.out.println(s.matches("[A-Z][a-z]{1,24}"));
        //System.out.println(s.matches("."));
        //System.out.println(s.matches(".*"));
        //System.out.println(s.matches("\\."));
        //Welcome to Java OR Welcome to HTML
        //System.out.println(s.matches("[A-Za-z$_][A-Za-z$_[\\d]]*"));
        //System.out.println(s.matches("[a-z]{3}[^\n]\\.[a-z]{3}[^\n]\\.[a-z]{3}[^\n]\\.[a-z]{3}[^\n]\\."));
        //System.out.println(s.matches("[\\d]{2}[\\D][\\d]{2}[\\D][\\d]{4}"));
        //System.out.println(s.matches("[\\S]{2}[\\s][\\S]{2}[\\s][\\S]{2}"));
        //System.out.println(s.matches("\\S{2}\\s\\S{2}"));
        //System.out.println(s.matches("[\\w]{3}[\\W][\\w]{10}[\\W][\\w]{3}"));//[\\w]{10}[\\w]{3}"));
        //System.out.println(s.matches("[\\d][\\w]{4}[\\.]"));
        //System.out.println(s.matches("[1,2,3][1,2,0][x,s,0][3,0,A,a][x,s,u][.,]"));
        //ystem.out.println(s.matches("[\\D][^aeiou][^bcDF][^\r\n\t\f<space>][^AEIOU][^.,]"));//[^AEIOU][^.,]
        //System.out.println(s.matches("[a-z][1-9][^a-z][^A-Z][A-Z].*"));
        //System.out.println(s.matches("[a-zA-Z02468]{40}[13579\\s]{5}"));
        //System.out.println(new Double(4.5).toString());
        //Scanner input = new Scanner(System.in);

    // Prompt the user to enter a string
    /*System.out.print("Enter a string: ");
    String s = input.nextLine();

    // Display result
    System.out.println("Ignoring non-alphanumeric characters, \nis "
      + s + " a palindrome? " + isPalindrome(s));*/
    String[] tokens="Java#html#perl".split("3");
        //System.out.println(Arrays.asList(tokens));
        for (int i=0;i<tokens.length;i++)
            System.out.print(tokens[i]+" ");
        
        
        
        
        
    }
        
        
        
              

    public static void myMethod(String UserName){
      //4 letters and one digit start with capital letter
        System.out.println(UserName.matches("[A-Z](?=.*[\\d][a-za-z\\d]{4}"));
      
            

      
      
      
      
      
      
  }    
    public static boolean isPalindrome(String s) {
    // Create a new string by eliminating non-alphanumeric chars
    String s1 = filter(s);

    // Create a new string that is the reversal of s1
    String s2 = reverse(s1);

    // Compare if the reversal is the same as the original string
    return s2.equals(s1);
  }

  /** Create a new string by eliminating non-alphanumeric chars */
  public static String filter(String s) {
    // Create a string builder
    StringBuilder stringBuilder = new StringBuilder();

    // Examine each char in the string to skip alphanumeric char
    for (int i = 0; i < s.length(); i++) {
      if (Character.isLetterOrDigit(s.charAt(i))) {
        stringBuilder.append(s.charAt(i));
      }
    }

    // Return a new filtered string
    return stringBuilder.toString();
  }

  /** Create a new string by reversing a specified string */
  public static String reverse(String s) {
    StringBuilder stringBuilder = new StringBuilder(s);
    stringBuilder.reverse(); // Invoke reverse in StringBuilder
    return stringBuilder.toString();
  }
}

