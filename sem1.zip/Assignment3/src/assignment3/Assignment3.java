/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Assignment3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int gen=(int)(Math.random()*100);
        System.out.println(gen);
        System.out.print("Guess a number between 1 and 100: ");
        int guess=input.nextInt();
        System.out.println("the random number is: "+gen);
        System.out.print("enter your bill amount: ");
        double bill=input.nextDouble();
        double dPrice,total;
        int shipping;
        if (guess==gen) {
            System.out.println("CONGRATS! you got a 100% discount");
            System.out.println();
            int discount=100;
            dPrice=bill-(bill*discount/100);
            if (bill>500){
               shipping=0;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            else {
                shipping=25;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            
            
            
            
        }
        else{
            if (guess%gen==0){
              System.out.println("CONGRATS! you got a 20% discount");
              int discount=20;
              dPrice=bill-(bill*discount/100);
              if (bill>500){
               shipping=0;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
              else {
               shipping=25;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            
            }
            else if (guess%gen==1){
              System.out.println("CONGRATS! you got a 2% discount");
              int discount=2;
              dPrice=bill-(bill*discount/100);
              if (bill>500){
               shipping=0;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            else {
               shipping=25;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            }
           else if (guess%gen==2){
              System.out.println("CONGRATS! you got a 3% discount");
              int discount=3;
              dPrice=bill-(bill*discount/100);
              if (bill>500){
               shipping=0;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            else {
               shipping=25;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            }
            else if (guess%gen==3){
            System.out.println("CONGRATS! you got a 5% discount");
            int discount=5;
            dPrice=bill-(bill*discount/100);
            if (bill>500){
               shipping=0;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            else {
               shipping=25;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            }
            else if (guess%gen==4){
              System.out.println("CONGRATS! you got a 2% discount");
              int discount=2;
              dPrice=bill-(bill*discount/100);
              if (bill>500){
                 shipping=0;
                 total=dPrice+shipping;
                 System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
              else {
                 shipping=25;
                 total=dPrice+shipping;
                 System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            }
            else if (guess%gen==5){
              System.out.println("CONGRATS! you got a 10% discount");
              int discount=10;
              dPrice=bill-(bill*discount/100);
              if (bill>500){
               shipping=0;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            else {
                shipping=25;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            }
            else if (guess%gen==6){
              System.out.println("CONGRATS! you got a 12% discount");
              int discount=12;
            dPrice=bill-(bill*discount/100);
            if (bill>500){
               shipping=0;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            else {
                shipping=25;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            }
            else {
              System.out.println("CONGRATS! you got a 1% discount");
              int discount=1;
              dPrice=bill-(bill*discount/100);
              if (bill>500){
               shipping=0;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            else {
                shipping=25;
               total=dPrice+shipping;
               System.out.println("Final bill: "+"$"+(int)dPrice+"\n"+"Shipping cost: "+"$"+(int)shipping+"\n"+"total: "+"$"+(int)total);
            }
            }
            
            
        }
            
        
    }
    
}
