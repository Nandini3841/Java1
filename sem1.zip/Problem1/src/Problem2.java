/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Stu
 */
import java.util.Scanner;
public class Problem2 {
    public static void main(String[] args){
        //NAME:NANDINI BOGINENI
        //STUDENT ID:202112115
        System.out.println("this is a program which asks the user to guess the number within the range 34 and 55");
        Scanner input=new Scanner(System.in);
        //generating a number between 34 and 55,excl 55
        int gen=(int)(34+Math.random()*21);
        //System.out.println("NUMBER GENERATED: "+gen);
        System.out.print("guess a random number between 34 and 55, excluding 55");
        int guess=input.nextInt();
        if (guess>=34 && guess<55) {
            if(guess==gen) {
                System.out.println("YOUR GUESS IS CORRECT!\nThe number is "+gen);   
            }
            else {
                System.out.println("YOUR GUESS IS WRONG!\nThe number is "+gen);
                
            }
            
        }
        else {
            System.out.println("INVALID INPUT! YOU HAVE ENTERED A NUMBER OUT OF THE SPECIFIED RANGE");
        }
    
        
        
        
        
    }
    
}
