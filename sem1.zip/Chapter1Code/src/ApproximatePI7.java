/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class ApproximatePI7 {
    public static void main(String[] args) {
        System.out.print("π=");
        System.out.println(((1.0-1.0/3+1.0/5-1.0/7+1.0/9-1.0/11)*4.0));
        
    }
    
}
