/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DisplayAPattern1;

/**
 *
 * @author user
 */
public class DisplayAPattern3 {
    public static void main(String[] args) {
        System.out.println("  J  ");
        System.out.println("J aaa   v   vaaa");
        System.out.println("J J aa   v v   a a");
        System.out.println("J  aaaa   v    aaaa");
    }
    
}
