/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class PrintATable4 {
    public static void main(String[] args) {
        System.out.println("a       a^2     a^3     a^4");
        System.out.println("1        1       1        1");
        System.out.println("2        4       8        16");
        System.out.println("3        9       27       81");
        System.out.println("4        16      64       256");
    }
    
}
