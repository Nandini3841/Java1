/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class AAndP9 {
    public static void main(String[] args) {
        /*double width,height,P,A;
        width=5.3;
        height=8.6;
        P=2*(width+height);
        A=width*height;
        System.out.println(A);
        System.out.println(P);*/
        
    }
    
}
