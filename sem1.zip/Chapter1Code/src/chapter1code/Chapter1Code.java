/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter1code;

/**
 *
 * @author user
 */
public class Chapter1Code {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("3.5 * 4 / 2 – 2.5 is ");
        System.out.println(((3.5*4)/(2-2.5)));

    }
    
}
