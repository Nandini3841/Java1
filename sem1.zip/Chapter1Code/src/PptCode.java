/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class PptCode {
    public static void main(String[] args)  {
        //1
        System.out.println("Welcome to Java!");
        
        //2
       // System.out.println("Welcome to Java);  SYNTAX ERROR/COMPILATION ERROR
       //System.out.println(1/0);  RUNTIME ERROR
       //System.out.println("celcius 35 is fahrenheit degree ");
       //System.out.println((9/5)*35+32);       LOGIC ERROR
        
    }
    
}
