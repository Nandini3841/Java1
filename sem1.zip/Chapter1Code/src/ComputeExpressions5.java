/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class ComputeExpressions5 {
    public static void main(String[] args) {
        System.out.print("7.5*6.5-4.5*3/47.5-5.5=");
        System.out.println(((7.5*6.5)-(4.5*3))/(47.5-5.5));
    }
    
}
