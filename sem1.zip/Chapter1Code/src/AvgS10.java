/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class AvgS10 {
    public static void main(String[] args) {
        double km,mins,as;
        km=15;
        mins=0.8416;
        as=(km/1.6)/mins;
        System.out.println("the avg speed is "+as);
        //AS12.max();
        System.out.println(AS12.max(2,5));
    }
    
}
