/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class AAndP8 {
    public static void main(String[] args) {
        final double PI=3.14159;
        double radius=6.5;
        double perimeter=2*radius*PI;
        double area=Math.pow(radius, 2)*PI;
        System.out.println("the perimeter of the circle with radius 6.5 is "+perimeter+" ,given that the valye of PI is 3.14159");
        System.out.println("the area of the circle with radius 6.5 units is "+area+" ,given that the value of Pi is 3.14");
        
    }
    
}
