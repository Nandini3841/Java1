/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class PopProj11 {
    public static void main(String[] args) {
        double y1,y2,y3,y4,y5;
        y1=312032486*41*365*24*60*60;
        
        
    }
    
}
