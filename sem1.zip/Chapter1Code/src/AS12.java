/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class AS12 {
    public static void main(String[] args) {
        double mile,hour,speed;
        mile=24;
        hour=1.6763;
        speed=(mile*1.6)/hour;
        System.out.println(speed);
        
        
    }
    public static double max(double...num1){
            double max=num1[0];
            for (int i=0;i<num1.length;i++)
                if (max<num1[i])
                    max=num1[i];
            return max;     
        }
    
}
