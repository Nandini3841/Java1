/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgswitch;

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Switch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        /*System.out.println("enter numbers from 1-7");
        int day=input.nextInt();
        
        switch(day) {
            case 1:System.out.println("Sunday");break;
            case 2:System.out.println("Monday");break;
            case 3:System.out.println("Tuesday");break;
            case 4:System.out.println("Wednesday");break;
            case 5:System.out.println("Thursday");break;
            case 6:System.out.println("Friday");break;
            case 7:System.out.println("Saturday");break;
            default:System.out.println("INVALID INPUT");*/
        /*System.out.println("chinese zodiac");
        System.out.print("enter year here:");
        int year=input.nextInt();
        switch (year%12) {
            case 0:System.out.println("monkey");
            case 1:System.out.println("rooster");
            case 2:System.out.println("dog");
            case 3:System.out.println("pig");
            case 4:System.out.println("rat");
            case 5:System.out.println("ox");
            case 6:System.out.println("tiger");
            case 7:System.out.println("rabbit");
            case 8:System.out.println("dragon");
            case 9:System.out.println("snake");
            case 10:System.out.println("horse");
            case 11:System.out.println("sheep");*/
        
        
        /*System.out.println("lottery");
        int gen=(int)(Math.random()*100);
        System.out.print("enter");
        int guess=input.nextInt();
        if (guess==gen) {
            System.out.println("10k");
        }
        else {
            System.out.println("no. the number is "+gen);
        }*/  
        
        /*System.out.println("lottery2");
        int gen=(int)(Math.random()*100);
        System.out.print("enter");
        int guess=input.nextInt();
        int digit1=gen/10;
        int digit2=gen%10;
        
        if (guess==gen) {
            System.out.println("10k");
        }
        else if ()*/
        //System.out.println((int)Math.random()*4);
        //int num=09;
        //float x=1.0;  
        //System.out.println(4+20/(3-1)*2);
        System.out.println((double)(1/2));
        
        
        
        
        
        
        
        
        
            
            
        
        
    }
    
}
