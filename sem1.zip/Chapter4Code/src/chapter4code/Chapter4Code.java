/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter4code;

/**
 *
 * @author user
 */
//import java.util.Scanner;
public class Chapter4Code {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*Scanner input=new Scanner(System.in);
        System.out.print("enter the character here");
        String s=input.next();
        char ch=s.charAt(0);
        if (ch>='A' && ch<='Z') {
            System.out.println("capital letter");
        }
        else if(ch>='a' && ch<='z') {
            System.out.println("small letter");
        }
        else {
            System.out.println("number");
        
        }*/
        //String msg="welcome to java";
        //System.out.println(msg.indexOf("come"));
        //System.out.printf("%9.7s%n", "ABCDEFGH");
       // System.out.printf("%4d%n", 6677);
       //System.out.printf("Total is:%5.2f%n",6.97887);
       System.out.printf("%10s%-10.89s", "Name","Age");
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
        
        
        
    }
    
}
