/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Rev7 {
    public static void main(String[] args) {
        System.out.println("this program prints the string in reverse");
        Scanner input=new Scanner(System.in);
        System.out.print("enter the string here:");
        String str=input.nextLine();
        System.out.println("the original string is: "+str);
        String rev;
        
        for (int i=0;i<str.length();i++) {
           
        
    }
        
        
}
}
