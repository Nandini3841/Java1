/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Char3 {
    public static void main(String[] args) {
        System.out.println("ENTER A CHARACTER AND RECEIVE ITS ASCII CODE");
        Scanner input=new Scanner (System.in);
        System.out.print("enter the character here");
        String ch=(char) input.next();
        
        System.out.println("the ASCII code for the character "+ch+" is: ":(char)ch);
        
        
        
        
        
    }
    
}
