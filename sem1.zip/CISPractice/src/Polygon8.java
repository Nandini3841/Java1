/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */

import java.util.Scanner;
public class Polygon8 {
    public static void main(String[] args) {
        Scanner input=new Scanner (System.in);
        System.out.print("enter the number of sides:");
        int num=input.nextInt();
        System.out.print("enter the value of side:");
        double s=input.nextDouble();
        System.out.println("the area of the polygon is: "+area(num,s));
        
        
}
public static double area(int n,double s) {
  return (n*(s*s)/(4*(Math.tan(Math.PI/n))));
          } 
}
