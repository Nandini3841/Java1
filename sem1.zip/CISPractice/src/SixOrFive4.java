/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class SixOrFive4 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("enter your number as integer:");
        int inp=input.nextInt();
        if (inp%6==0 && inp%5==0) {
            System.out.println(inp+" is divisible by 5 and 6");
        }
        else if(inp%6==0 || inp%5==0) {
            System.out.println(inp+" is divisible by 5 or 6");
        }
        else if(inp%6==0 ^ inp%5==0) {
            System.out.println(inp+" is divisible by 5 or 6 but not both");
        }
    }
}
