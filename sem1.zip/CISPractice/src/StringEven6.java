/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class StringEven6 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("Enter the string here: ");
        String inp=input.nextLine();
        for (int i=0;i<inp.length();i++) {
            if (i%2==0) {
                System.out.println(inp.charAt(i)+" ");
            }
            else {
                continue;
            }
        }
        
        
        
        
        
    }
}
