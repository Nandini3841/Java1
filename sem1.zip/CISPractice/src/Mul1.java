/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Mul1 {
    public static void main(String[] args) {
       System.out.println("MULTIPLICATION QUIZ");
       int num1=(int) (Math.random()*100);
       int num2=(int) (Math.random()*100);
       int ans=num1*num2;
       Scanner input=new Scanner(System.in);
       System.out.print(num1+"*"+num2+"=");
       int guess=input.nextInt();
       if (guess==ans) {
           System.out.println("CORRECT ANSWER!!!");
       }
       else {
           System.out.println("YOU ARE WRONG!");
           System.out.println("The answer is: "+ans);
       }
       
       
       
       
       
       
}
}
