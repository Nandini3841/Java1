/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Caps9 {
    public static void main(String[] args) {
        int count=0;
        Scanner input=new Scanner(System.in);
        System.out.print("enter the string here:");
        String inp=input.nextLine();
        for (int i=0;i<inp.length();i++) {
            if (Character.isUpperCase(inp.charAt(i))) {
                count++;
            }
            else {
                continue;
            }
    }
        System.out.println("the number of cap letters in the string is: "+count);
}
}