/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Flip2 {
    public static void main(String[] args) {
        System.out.println("GUESS AFTER FLIPPING A COIN");
        Scanner input=new Scanner(System.in);
        System.out.print("Enter \'0\' for head and \'1\' for tail");
        int guess=input.nextInt();
        int gen=(int)(Math.random()*2);
        if (guess==gen) {
            System.out.println("CORRECT");
        }
        else if (guess==0) {
            System.out.println("Wrong.The outcome after flipping is tail");
        }
        else if (guess==1) {
            System.out.println("Wrong.The outcome after flipping is head");
        }
        else {
            System.out.println("Sorry, the input is out of range");
            guess=input.nextInt();
        }
    }
    
}
