/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Hex16 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("enter the side of the hexagon:");
        double side=input.nextDouble();
        double area=((3.0/2)*(Math.pow(3,0.5)))*Math.pow(side,2);
        System.out.println("the area of the hexagon is "+area);
    }
    
}
