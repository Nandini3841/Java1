/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class RunwayLt12 {
    public static void main(String[] args) {
        System.out.println("this is a program to compute the runway length");
        System.out.print("enter the velocity in m/s");
        Scanner input=new Scanner(System.in);
        double velocity=input.nextDouble();
        System.out.print("enter the acceleraton in m/s^2");
        double accn=input.nextDouble();
        double run=Math.pow(velocity,2)/(2*accn);
        System.out.println("the runway length is: "+run+" given that the velocity is "+velocity+" and acceleration is "+accn);
        
        
        
        
        
        
        
        
    }
    
}
