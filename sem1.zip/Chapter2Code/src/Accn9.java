/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
import java.io.*;
public class Accn9 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("this is a program to compute acceleration");
        double v0,v1,t,accn;
        System.out.print("enter v0 here:");
        v0=input.nextDouble();
        System.out.print("enter v1 here:");
        v1=input.nextDouble();
        System.out.print("enter t here:");
        t=input.nextDouble();
        accn=((v1-v0)/t);
        System.out.println("the average acceleration is:"+accn);
        
        
        
        
        
        
        
        
        
    }
        
     
        
        
    
     
}
