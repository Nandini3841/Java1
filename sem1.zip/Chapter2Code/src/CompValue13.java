/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class CompValue13 {
    public static void main(String[] args) {
        System.out.println("this is a program to compute savings");
        Scanner input=new Scanner(System.in);
        System.out.print("enter the monthly saving amount");
        double save=input.nextDouble();
        System.out.print("enter the annual interest");
        double ann=input.nextDouble();
        double month=ann/1200;
        double first=save*(1+month);
        double second=(first+100)*(1+month);
        double third=(second+100)*(1+month);
        double fourth=(third+100)*(1+month);
        double fifth=(fourth+100)*(1+month);
        double sixth=(fifth+100)*(1+month);
        System.out.println("After the first month, the account value is "+first);
        System.out.println("After the second month, the account value is "+second);
        System.out.println("After the third month, the account value is "+third);
        System.out.println("After the fourth month, the account value is "+fourth);
        System.out.println("After the fifth month, the account value is "+fifth);
        System.out.println("After the sixth month, the account value is "+sixth);
        
        
        
        
    }
    
}
