/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class NoOfYears7 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        //System.out.println(1902.585719%1902);
        System.out.print("enter the number of minutes:");
        double min=input.nextDouble();
        double yrs=min/525600;
        int yrs1=(int) yrs;
        double temp=(yrs%((int)yrs));
        double temp1=365*(temp);
        int days=(int)temp1;
        System.out.println(min+" minutes is approximately "+yrs1+" years and "+days+" days");
    }
    
}
