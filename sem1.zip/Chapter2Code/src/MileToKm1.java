/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 import java.util.Scanner;
/**
 *
 * @author user
 */
public class MileToKm1 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("This is a program to convert miles to kilometers");
        System.out.print("enter miles here:");
        double miles=input.nextDouble();
        double km =miles*1.6;
        System.out.println(miles+" miles is "+km+" km");
        
        
        
    }
    
}
