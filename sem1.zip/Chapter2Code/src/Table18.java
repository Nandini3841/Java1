/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Table18 {
    public static void main(String[] args) {
        System.out.printf("%8s%8s%20s","a","b","Middle Point\n");
        System.out.printf("    (%d,%d)   (%d,%d)    (%f,%f)",0,0,2,1,((0+0)/2.0),(0+1/2.0));
        System.out.println();
        System.out.printf("    (%d,%d)   (%d,%d)    (%f,%f)",1,4,4,2,((1+4)/2.0),(4+2/2.0));
        System.out.println();
        System.out.printf("    (%d,%d)   (%d,%d)    (%f,%f)",2,7,6,3,((2+6)/2.0),(7+3/2.0));
        System.out.println();
        System.out.printf("    (%d,%d)   (%d,%d)   (%f,%f)",3,9,10,5,((3+10)/2.0),(9+5/2.0));
        System.out.println();
        System.out.printf("    (%d,%d)  (%d,%d)   (%f,%f)",4,11,12,7,((4+12)/2.0),(11+7/2.0));
        System.out.println();
        
        
        
        
    }
    
}
