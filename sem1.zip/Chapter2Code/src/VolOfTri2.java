/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author user
 */
public class VolOfTri2 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("enter length of the sides and height of the equilateral triangle here:");
        double dim=input.nextDouble();
        double area=(((Math.sqrt(3))*(Math.pow(dim,2)))/4);
        double vol=area*dim;
        System.out.println("the area is "+area);
        System.out.println("the volume of the triangular prism is "+vol);
    }
    
}
