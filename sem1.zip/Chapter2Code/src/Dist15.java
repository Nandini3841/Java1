/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Dist15 {
    public static void main(String[] args) {
        System.out.println("this is a program to compute the distance");
        Scanner input=new Scanner(System.in);
        System.out.print("enter x1:");
        double x1=input.nextDouble();
        System.out.print("enter x2:");
        double x2=input.nextDouble();
        System.out.print("enter y1:");
        double y1=input.nextDouble();
        System.out.print("enter y2:");
        double y2=input.nextDouble();
        double dist=Math.pow(((Math.pow((x2-x1),2))+(Math.pow((y2-y1),2))),0.5);
        System.out.println("the distance is :"+dist);
                
                
    }
    
}
