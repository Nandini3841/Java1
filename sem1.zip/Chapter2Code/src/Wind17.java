/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Wind17 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("enter the temperature in Fahrenheit between-58F and 41F:");
        double temp=input.nextDouble();
        System.out.print("enter the wind speed(>=2) in miles per hour");
        double wind=input.nextDouble();
        if (temp<-58 || temp>41) {
            System.out.println("INVALID TEMPERATURE");
        }
        if (wind<2) {
            System.out.println("INVALID WIND SPEED");
        }
        double index=35.74+(0.6215*temp)-(35.75*(Math.pow(wind,0.16)))+(0.4275*temp*(Math.pow(wind,0.16)));
        System.out.println("the wind chill index is "+index);
        
        
        
        
        
        
        
    }
        
}
