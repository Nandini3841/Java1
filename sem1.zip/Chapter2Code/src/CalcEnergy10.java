/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class CalcEnergy10 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("this is a program to compute the energy required to heat water");
        double M,inTemp,finTemp,Q;
        System.out.print("enter the weight of water in kilograms");
        M=input.nextDouble();
        System.out.print("enter the initial temperature of water");
        inTemp=input.nextDouble();
        System.out.print("enter the final temperature of water");
        finTemp=input.nextDouble();
        Q=M*(finTemp-inTemp)*4184;
        System.out.println("the energy needed is "+Q);
        
        
        
        
        
        
    }
    
}
