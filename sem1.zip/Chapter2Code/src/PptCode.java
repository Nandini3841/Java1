/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class PptCode {
    public static void main(String[] args) {
        //1
        long num=123456;
        System.out.print(num);
        
        //2
        /* NAME:NANDINI BOGINENI
           STUDENT ID:202112115
           SECTION:
           INSTRUCTOR NAME:MS.ALLA ALHARAZI
        */
        //1
        final double PI=3.14159;
        /*System.out.println("This is a program to compute the area of a circle");
        double radius,area;
        radius=5;
        
        area=Math.pow(radius,2)*PI;
        System.out.println("The area of a circle with radius "+radius+" units is "+area+" square units, given that the value of Pi is "+PI);*/
        Scanner input=new Scanner(System.in);
        
        //2
        /*System.out.println("this is a program to obtain the double value from the user");
        System.out.print("enter the number here:");
        double d=input.nextDouble();
        System.out.println(d);*/
        
        //3
        /*System.out.println("This is a program to compute the area of a circle, by taking  input from the user");
        double rad,ar;
        System.out.print("enter radius here:");
        rad=input.nextDouble();
        ar=Math.pow(rad,2)*PI;
        System.out.println("The area of a circle with radius "+rad+" units is "+ar+" square units, given that the value of Pi is "+PI);*/
        
        //3
        /*System.out.println("this is a program to compute the average taking input from the user");
        System.out.println("Enter each number after pressing space");
        double num1=input.nextDouble();
        double num2=input.nextDouble();
        double num3=input.nextDouble();
        double sum=num1+num2+num3;
        System.out.println(sum);*/
        
        //4
        /*System.out.println("this is a program to convert fahrenheit to celcius");
        System.out.print("enter the fahrenheit value here:");
        double fah=input.nextDouble();
        double cel=(5.0/9)*(fah-32);
        System.out.println(cel);*/
        
        //5
        /*System.out.println("this is a program to compute a loan payment");
        System.out.print("enter annual interest here:");
        double annual=input.nextDouble();
        System.out.print("enter number of years here:");
        double years=input.nextDouble();
        System.out.print("enter loan amount here:");
        double loanAmt=input.nextDouble();
        double monthlyInterestRate=annual/1200;
        double monthlyPayment=((loanAmt*monthlyInterestRate)/(1-(1/Math.pow(1+monthlyInterestRate,2))));
        double totalPayment=monthlyPayment*years*12;
        System.out.printf("Total amount is:%f\nMonthly amount is:%f",totalPayment,monthlyPayment);*/
        
        

        
        
        
    }
    
}
