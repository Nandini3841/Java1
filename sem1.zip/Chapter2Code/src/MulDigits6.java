/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */

import java.util.Scanner;
public class MulDigits6 {
    public static void main(String[] args) {
        System.out.print("Enter the number to get the multiplication of its digits:");
        Scanner input=new Scanner(System.in);
        int num=input.nextInt();
        int dig1=num%10;
        int temp=num/10;
        int dig2=temp%10;
        int dig3=temp/10;
        int mul=dig1*dig2*dig3;
        System.out.println(dig1);
        System.out.println(dig2);
        System.out.println(dig3);
        System.out.println(mul);
    }
    
}
