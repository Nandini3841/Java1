/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.io.*;
import java.util.*;
public class FindingRunwayLength12 {
    public static void main(String[] args) throws IOException{
        System.out.println("This is a program to compute the monthy installment of products");
        System.out.println("Number              Category               Interest rate");
        System.out.println("1                     Phone                        2%");
        System.out.println("2                     Tablet                       4%");
        System.out.println("3                     PC                           6%");
        System.out.println("4                     Other products               10%");

        
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.print("Enter your name here: ");
        String name = input.readLine();
       
        System.out.println("Enter the number of the product in the category you want to buy: ");
        int itemNum = input.read();

        input.readLine();
        System.out.println("Enter the name of the product: ");
        String itemName = input.readLine();

        System.out.println("Enter the price of the product: ");
        String price_str = input.readLine();
        double price = Double.valueOf(price_str).doubleValue();

        System.out.println("Enter the number of months");
        int months = input.read();
        input.readLine();


        if (itemNum==1) {
        System.out.println("Enter the rate of interest for this product");
        String roi_str = input.readLine();
        double roi = Double.valueOf(roi_str).doubleValue();
        double rate=(price*roi)/100;
        double inst=(price/months)+rate;
        System.out.println("Thank you "+name+" for buying "+itemName+"from our store. Your monthly installment is: "+inst);
        }


        else if (itemNum==2) {
        System.out.println("Enter the rate of interest for this product: ");
        String roi_str = input.readLine();
        double roi = Double.valueOf(roi_str).doubleValue();
        double rate=(price*roi)/100;
        double inst=(price/months)+rate;
        System.out.println("Thank you "+name+" for buying "+itemName+" from our store. Your monthly installment is: "+inst);
        }


        else if (itemNum==3) {
        System.out.println("Enter the rate of interest for this product: ");
        String roi_str = input.readLine();
        double roi = Double.valueOf(roi_str).doubleValue();
        double rate=(price*roi)/100;
        double inst=(price/months)+rate;
        System.out.println("Thank you "+name+" for buying "+itemName+" from our store. Your monthly installment is: "+inst);
        }


        else {
        System.out.println("Enter the rate of interest for this product: ");
        String roi_str = input.readLine();
        double roi = Double.valueOf(roi_str).doubleValue();
        double rate=(price*roi)/100;
        double inst=(price/months)+rate;
        System.out.println("Thank you "+name+" for buying "+itemName+" from our store. Your monthly installment is: "+inst);
        }
    }
    
    
}
