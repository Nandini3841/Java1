/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class BMI14 {
    public static void main(String[] args) {
        System.out.println("this is a program to compute BMI");
        Scanner input=new Scanner(System.in);
        System.out.print("enter weight in pounds");
        double weight=input.nextDouble();
        
        System.out.print("enter height in inches");
        double height=input.nextDouble();
        double BMI=(((weight)/((Math.pow(height,2))))*703);
        System.out.println("your BMI is "+BMI);
    }
    
}
