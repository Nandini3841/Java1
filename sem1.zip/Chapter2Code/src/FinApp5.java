/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class FinApp5 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("Enter the subtotal:");
        double sub=input.nextDouble();
        System.out.print("enter the gratituity rate");
        double gra=input.nextDouble();
        double gra1=gra/10;
        double total=sub+gra1;
        System.out.println("The gratituity is $"+gra1+" and total is $"+total);
        
        
    }
    
}
