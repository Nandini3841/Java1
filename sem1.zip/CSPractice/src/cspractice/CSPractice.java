/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cspractice;

/**
 *
 * @author user
 */import java.util.Scanner;
public class CSPractice {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner input=new Scanner(System.in);
        //1
        /*System.out.println("MULTIPLICATION QUIZ");
        int num1,num2,prod,ans;
        num1=(int)(Math.random()*100);
        num2=(int)(Math.random()*100);
        prod=num1*num2;
        System.out.print(num1+"*"+num2+"=");
        ans=input.nextInt();
        if (ans==prod) 
            System.out.println("CORRECT ANSWER!");
        else
            System.out.println("WRONG ANSWER!THE CORRECT ANSWER IS: "+prod);*/
        
        //2
        /*System.out.println("GUESSING GAME");
        int gen,guess;
        gen=(int)(Math.random()*2);
        System.out.println(gen);
        System.out.print("enter \'0\' for head or \'1\' for tail: ");
        guess=input.nextInt();
        if (guess==gen) {
            System.out.println("CORRECT GUESS!");
        }
        else if (guess==1) {
            System.out.println("SORRY,IT IS A HEAD");
        }
        else if (guess==0) {
            System.out.println("SORRY,IT IS A TAIL");
        }
        else  {
            System.out.println("INVALID INPUT");
        }*/
        
        //3
        /*System.out.println("THIS PROGRAM RETRIEVES A CHARACTER FROM THE USER AND RETURNS ITS ASCII CODE");
        System.out.print("enter the character: ");
        String ch=input.next();
        int ascii=(int)(ch.charAt(0));
        System.out.println("THE ASCII CODE OF THE CHARACTER \'"+ch+"\' IS "+ascii);*/
        /*System.out.println("THIS PROGRAM RETRIEVES THE ASCII CODE FROM THE USER AND RETURNS THE CORRESPONDING CHARACTER");
        System.out.print("enter the ascii code here");
        int num=input.nextInt();
        char ch=(char)num;
        System.out.println(ch);*/
        
        
        //4
        /*System.out.print("enter an integer:");
        int num=input.nextInt();
        System.out.println("is "+num+" divisible by 6 and 5? "+(num%5==0 && num%6==0));
        System.out.println("is "+num+" divisible by 6 or 5? "+(num%5==0 || num%6==0));
        System.out.println("is "+num+" divisible by 6 or 5 but not both? "+(num%5==0 ^ num%6==0));*/
        
        //5
        /*System.out.print("enter a string:");
        String str=input.nextLine();
        System.out.println("THE LENGTH OF THE STRING IS: "+str.length()+" and its first character is: "+str.charAt(0));*/
        
        
        //6
        /*System.out.print("ENTER A STRING: ");
        String str=input.nextLine();
        System.out.print("the characters at even positions are: ");
        for (int i=0;i<str.length();i++)
            if (i%2==0)
                  System.out.print(str.charAt(i)+" ");*/
        
        //7
        /*System.out.print("enter the length of the array:");
        int lt=input.nextInt();
        int[] lst=new int[lt];
        for (int i=0;i<lst.length;i++) {
            System.out.print("enter element "+i+": ");
            lst[i]=input.nextInt();
            
        }
        int[] reve=reverse(lst);
        System.out.print("the list before reversing is: ");
        for (int value:lst)        
            System.out.print(value);
        System.out.print("\nThe list after reversing is: ");
        for (int value:reve)        
            System.out.print(value);*/
        
        //8
        //int sum=0;
        //sum+=4.5;
        //System.out.println(sum);
        //System.out.println(Math.ceil(2));
        //System.out.println(Math.max(2.0,3));
        //System.out.println('\u0632');
        /*int count=5;
        double amount=45.56;
        System.out.printf("count is %d and amount is %f", count,amount);
        System.out.println();*/
        
        //System.out.printf("%4d%n",6677);
        /*int[] lst=new int[2];
        //System.out.println(lst[0]);
        System.out.println("ننطينيييييييييييي");
        System.out.println("ربيييييييااااااّ");
        System.out.println("سوويبااااا");*/
        /*int[] rand=new int[100];
        int sum=0;
        int avg=0;
        int count=0;
        for (int i=0;i<rand.length;i++){
            rand[i]=(int)(Math.random()*51);
            sum+=rand[i];
        }
        avg=sum/100;
        for (int i=0;i<rand.length;i++){
            if (rand[i]>avg)
                count++;
        }
        System.out.println("total numbers that are above the average are: "+count);*/
        /*System.out.print("enter the length of the array: ");
        int lt=input.nextInt();
        double sum=0;
        double[] lst=new double[lt];
        for (int i=0;i<lst.length;i++){
            System.out.print("enter element "+(i+1)+":");
            lst[i]=input.nextDouble();
            sum+=lst[i];*/
        
       //System.out.println("the sum of the elements is: "+sum);
        /*System.out.println("the list is: ");
        for (double value:lst) 
            System.out.print(value+" ");
        System.out.println();*/
        //System.out.println(java.util.Arrays.toString(lst));   
        /*for (int i=0;i<lst.length;i++)
            System.out.print(lst[i]+" ");*/
        /*char[] myName={'N','A','N','D','I','N','I'};
        System.out.println(myName);
        for (char ch:myName)
            System.out.print(ch+"");
        System.out.println();*/
        /*double[] lst={1,4,3,9,7};
        System.out.print("enter the element that you're looking for: ");
        double req=input.nextDouble();
        double key=largest(lst,req);
        System.out.println("the largest element is: "+key);*/
        /*int s[] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
        int d[] = { 15, 25, 35, 45, 55, 65, 75, 85, 95, 105};
        System.arraycopy(s, 3, d, 5, 4);   
        for (int i = 0; i < d.length; i++){
            System.out.print(d[i] + " ");}*/
        /*VarArgs();
        VarArgs("A","B","C");
        VarArgs(new String[]{"D","E","F","G"});*/
        /*int[][] matrix=new int[5][5];
        for (int i=0;i<matrix.length;i++)
            for(int j=0;j<matrix[i].length;j++)
                matrix[i][j]=(int)(Math.random()*11);
        for (int i=0;i<matrix.length;i++){
            for(int j=0;j<matrix[i].length;j++)
                
                System.out.println(matrix[i][j]+" ");
        }
        System.out.println();*/
        //System.out.println(sum(1,10));
        //System.out.println(sum(20,30));
       // System.out.println(sum(35,45));
        //System.out.println(max(2,5,4,3,10));
        //System.out.println(max(2,5));
        /*int num1,num2,sum,ans;
        num1=(int)(Math.random()*11);
        num2=(int)(Math.random()*11);
        sum=num1+num2;
        System.out.print(num1+"+"+num2+"=");
        ans=input.nextInt();
        while (sum!=ans) {
            System.out.print("wrong.enter here: ");
            ans=input.nextInt();
        }*/
        //System.out.println("correct");
        //System.out.print(Math.PI);
        //System.out.println(Math.ceil(2));
        //int bw50and99=50+(int)(Math.random()*100);
        /*double n,s;
        System.out.print("ENTER THE NUMBER OF SIDES OF THE POLYGON");
        n=input.nextDouble();
        System.out.print("ENTER THE SIDE MEASURE OF THE POLYGON");
        s=input.nextDouble();
        Area(n,s);*/
        
        /*System.out.print("enter the string: ");
        String str=input.nextLine();
        int count=0;
        for (int i=0;i<str.length();i++) {
            char ch=str.charAt(i);
            if(Character.isUpperCase(ch))
                count++;
        }
        System.out.println("the number of caps in the string is: "+count);*/
        /*double sum=0;
        double avg;
        
        for (int i=0;i<5;i++) {
            System.out.print("enter grade "+(i+1)+" :");
            double grade=input.nextDouble();
            sum+=grade;
        }
        avg=sum/5;
        if (sum>60)System.out.println("you passed with average "+avg);
        else System.out.println("you failed");*/
       /* double[] lst=new double[10];
        int count=1;
        for (int i=0;i<lst.length;i++){
            System.out.print("enter element "+count);
            lst[i]=input.nextDouble();
            count++;
        }  
        System.out.println("the average of the elements is: "+average(lst));*/
        /*String ordName;
        double ordPrice;
        double high=0;
        String highName;
        int count=1;
        for (int i=0;i<2;i++) {
            System.out.print("enter order price "+count);
            ordPrice=input.nextDouble();
            System.out.print("enter order name "+count);
            ordName=input.next();
            count++;
            System.out.println();
            if(high<ordPrice){
                high=ordPrice;
                highName=ordName;
            }   
        }*/
       /*System.out.print("enter ur phone number(must contain 10 digits)");
       String phNum=input.next();
       if(phNum.length()==10) System.out.println("okay");
       else if(phNum.length()<10) System.out.println("less");
       else System.out.println("more");*/
       /*int[] array=new int[11];
       for (int i=0;i<array.length;i++){
           System.out.print("enter element "+(i+1)+":");
           array[i]=input.nextInt();
       }
       for (int value:array) System.out.print(value+" ");
       for (int i=0;i<array.length;i++){
           if (array[i]>array[10])
               System.out.println("greater than the last element");
           else if(array[i]<array[10])
           System.out.println("less than the last element");
           else 
               System.out.println("equal to the last element");
       }*/
       /*System.out.print("enter a string");
       String str=input.nextLine();
       String small=str.toLowerCase();
       int count=0;
       for (int i=0;i<small.length();i++) {
           if (small.charAt(i)=='a' || small.charAt(i)=='e' || small.charAt(i)=='i' ||small.charAt(i)=='o'  || small.charAt(i)=='u')
               count++;
           
       }
       System.out.println(count);*/
       /*double[][] arr=new double[4][4];
       double sum=0;
       for (int i=0;i<arr.length;i++){
           for (int j=0;j<arr[i].length;j++){
               System.out.print("enter the element"+i+""+j);
               arr[i][j]=input.nextDouble();
           }}   
       System.out.print("the avg is: "+avg(arr));*/
       /*String highName="";
       double highPrice=0;
       for (int i=0;i<2;i++){
           System.out.print("enter order name");
           String name=input.next();
           System.out.print("enter order price");
           double price=input.nextDouble();
           if(highPrice<price){
               highPrice=price;
               highName=name;  
       }    
       }
       System.out.println(highPrice);
       System.out.println(highName);*/
       /*System.out.print("enter a character: ");
       String str=input.next();
       char ch=str.charAt(0);
       int ascii=ch;
       System.out.println("THE ASCII CODE OF THE CHARACTER "+ch+" IS: "+ascii);*/
       /*System.out.print("enter a string:");
       String str=input.nextLine();
       String rev="";
       for(int i=0;i<str.length();i++)
           rev=str.charAt(i)+rev;
       System.out.println(rev);*/
       /*System.out.print("What is your name?");
       String name=input.nextLine();
       System.out.print("What product do you want to buy?");
       String item=input.nextLine();
       System.out.print("Enter the product price:");
       double price=input.nextDouble();
       System.out.print("Please enter the number of months:");
       int months=input.nextInt();
       System.out.print("Please enter the rate of interest for this product: ");
       double rate=input.nextDouble();
       double roi=(price*rate)/100;
       double installment=(price/months)+roi;
       System.out.println("Thank you "+name+" for buying "+item+" from our store.Your monthly installment is: "+installment);*/
      /* System.out.print("ENTER A STRING: ");
       String str=input.nextLine();
       String result="";
       for (int i=0;i<str.length();i++)
           result=result+str.charAt(i);
       System.out.println(result);*/
       //boolean x[][]=new boolean[3][];
       //x[0]=new boolean[1];
       //x[1]=new boolean[2];
       //x[2]=new boolean[3];
       //System.out.println(x[2][2]); ///RUNTIME ERROR
       /*int[][] array = {{1, 2, 3, 4}, {5, 6, 7, 8}};
        //int[][] array = {{1, 2, 3, 4}, {5, 6, 7, 8}};
       System.out.println(m1(array)[0]);
       System.out.println(m1(array)[1]);
       for (int i=0;i<array.length;i++)
           System.out.print(array[i][i]);*/
       //int i=new int[30];
       
       /*int i=016;
       System.out.println(i);*/
       
       //char ch='a';
       //System.out.println(ch);
       //System.out.println(Math.round(2.5));
       //System.out.println(Math.round(3.5));
       //char ch='a';
       //System.out.println(++ch);
       //System.out.println(++ch);
       /*int number1 = 5;
int number2 = 5;
String s = "Sara";
System.out.println(number1 + number2 + s);*/
//System.out.println("A".compareTo("d"));
//System.out.println(Math.sin(Math.PI));   
/*Character x = new Character('a');
x.equals(new Character('a'));
 x.compareToIgnoreCase('A');
 x.equalsIgnoreCase('A');
  x.equals('a');
 x.equals("a");*/
//String s="java";
//System.out.printf("%.2f\n", 1.23456);
 //System.out.printf("amount is %f %e\n", 32.32, 32.32);       
  //System.out.printf("amount is %5.2f%% %5.4e\n", 32.327, 32.32);      
    //System.out.println((char)0X40);    
     //ystem.out.println((char)0X5A);   
     //char x = 'a';
    //char y = 'c';
      /*System.out.println(++x);
      //System.out.println(y++);
      System.out.println(x);
      System.out.println(y);
      System.out.println(x - y);*/
      //System.out.println((char)(97+(int)(Math.random()*(122-97+1))));
      /*String s1=" Welcome ";
      String s2=" welcome ";
      boolean isEqual=s1.equals(s2);
      boolean isEqual_=s1.equalsIgnoreCase(s2);
      int x=s1.compareTo(s2);
      int x_=s1.compareToIgnoreCase(s2);
      boolean b=s1.startsWith("AAA");
      boolean b_=s1.endsWith("AAA");
      int y=s1.length();
      char a=s1.charAt(0);
      String s3=s1+s2;
      String str=s1.substring(1);
      String str1=s1.substring(1,4);
      String s4=s1.toLowerCase();
      String s5=s1.toUpperCase();
      String s6=s1.trim();
      int x1=s1.indexOf('e');
      int x2=s1.lastIndexOf("abc");
      int i=123;
      System.out.println((i+"").length());*/
      /*System.out.print("enter age");
      int age=input.nextInt();
      if (age < 16) 
  System.out.println("Cannot get a driver's license");
else 
  System.out.println("Can get a driver's license");*/
      /*int x=10;
       int y=10;
      System.out.println(x);
      System.out.println((y > 10) || (x-- > 10));
      System.out.println(x);*/
      //int num=010;
      //System.out.println(num);
     /*int[][] matrix=new int[3][2];
      for (int i=0;i<matrix.length;i++)
          for (int j=0;j<matrix[i].length;j++)
              matrix[i][j]=(int)(Math.random()*10);
      
      for (int i=0;i<matrix.length;i++)
          for (int j=0;j<matrix[i].length;j++)
            System.out.println(matrix[i][j]);
     int total = 0;
for (int column = 0; column < matrix[0].length; column++) {
for (int row = 0; row < matrix.length; row++){
    total += matrix[row][column];
  System.out.println("Sum for column " + column + " is " 
    + total);
}
total=0;*/
     //Character ch=new Character('a');
     //char[] charArray = new char[]{'a', 'b'};
      //int[] x = {1, 2, 3, 4, 5};
     //System.out.println(x[0]);
     
     //String[] a = new String [5];
     //String[] a = {"", "", "", "", ""};

     //System.out.println(a[0]);
     //System.out.println("hello world");
     //String[] a = {"", "", "", "", ""};
/*int[] list = {1, 2, 3, 4, 5};
int[] rev=new int[list.length];
for (int i = 0, j = list.length - 1; i < list.length; i++, j--) {
  // Swap list[i] with list[j]
  //int temp = list[i];
  rev[i] = list[j];
  //list[j] = temp;
}
for (int value:rev)
    System.out.println(value);*/
/*int[] list = {1, 2, 3, 4, 5};
    reverse(list);
    for (int i = 0; i < list.length; i++)
      System.out.print(list[i] + " ");*/
//System.out.println(78 % -4);     
//float x=;
/*int j = 0;
    int i = j++ + j * 5;hjitebklfbho;dfnakdjwefkwuhgkkdsdioqer23bhjfweil2gtu2gtu2gtu2gtu2gtu/////'qwrl23232323nfje2ie910qwjko;ra\

    System.out.println("What is i? " + i);*/
//System.out.println(1*(Math.pow(4,1.0/2)));

/*System.out.println("enter radius:");
int radius=input.nextInt();
double area=radius*radius*Math.PI;
System.out.println(area);*/
/*int i=0;
while (true);*/
sysout
        





     
}

      
      
      
      
 
        
        
        
        
        
        
               
        public static int[] revList(int[] list) {
            int[] rev=new int[list.length];
            for (int i=0,j=list.length-1;i<list.length;i++,j--) {
                rev[i]=list[j];
            }
            return rev;
        }
        public static double largest(double[] list,double key) {
            for (int i=0;i<list.length;i++) {
                if (key==list[i]){
                    return list[i];     
            }  
            }
            return -1;
        }
        public static void VarArgs(String...a) {
            System.out.println("number of arguments: "+a.length);
            System.out.println(java.util.Arrays.toString(a));
        }
        public static double linearSearch(double[] list,double key) {
            for(int i=0;i<list.length;i++)
                if (key==list[i])
                    return i;
            return -1;
        }
        public static int sum(int num1,int num2) {
            int sum=0;
            for (int i=num1;i<=num2;i++) 
                sum+=i;
            return sum;
            
        }
        public static double max(double...num1){
            double max=num1[0];
            for (int i=0;i<num1.length;i++)
                if (max<num1[i])
                    max=num1[i];
            return max;     
        }
        public static void Area(double n, double s) {
            double area;
            area=(n*(Math.pow(s,2)))/(4*(Math.tan(Math.PI/n)));
            System.out.println("THE AREA OF THE POLYGON WITH THE NUMBER OF SIDES: "+n+" WITH EACH SIDE MEASURING "+s+"IS: "+area);
        }
        public static int average(int[] array){
            int sum=0;
            int avg;
            for (int i=0;i<array.length;i++) 
                sum+=array[i];
            avg=sum/10;
            return avg;
        }
        public static double avg(double[][] arr){
            double sum=0;
            for (int i=0;i<arr.length;i++)
                for (int j=0;j<arr.length;j++)
                  sum+=arr[i][j];
            return sum/arr.length;
        }
        public static int[] m1(int[][] m) {
    int[] result = new int[2];
    result[0] = m.length;
    result[1] = m[0].length;
    return result;
  }
        public static void reverse(int[] list) {
    int[] newList = new int[list.length];

    for (int i = 0; i < list.length; i++)
      newList[i] = list[list.length - 1 - i];

    list = newList;
  }
               
             
            
            
        
        
        
        
    
      
            

            
        
        
        
        
        
        
        
        
    }
    

