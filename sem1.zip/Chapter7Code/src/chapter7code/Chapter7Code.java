/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter7code;

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Chapter7Code {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //int[] values;
       /*int[] values=new int[5];
       for (int i=1;i<5;i++) {
           values[i]=i+values[i-1];
           System.out.print(values[i]+" ");
       }
       values[0]=values[1]+values[4];*/
       
       //INITIALIZING ARRAYS WITH INPUT VALUES
       /*Scanner input=new Scanner(System.in);
       System.out.print("ENTER THE SIZE OF THE ARRAY");
       int size=input.nextInt();
       double[] inp=new double[size];
       for (int i=0;i<size;i++){
           System.out.print("enter element "+(i+1)+" which is at index "+i);
           inp[i]=input.nextInt();
       }
       System.out.print("THE ELEMENTS OF ARRAY ARE: ");
       for (int j=0;j<size;j++) {
           System.out.print((int)inp[j]+" ");
           
           
       }*/
       //INITIALIZING ARRAYS WITH RANDOM VALUES
       /*double[] rand=new double[5];
       for (int i=0;i<5;i++) {
           rand[i]=Math.random()*100;
           System.out.println(rand[i]);
       }*/
       /*int[] arr={1,2,3,4,5};
       System.out.print("THE ELEMENTS OF THE ARRAY ARE: ");
       for (int i=0;i<5;i++) {
           System.out.print(arr[i]+" ");
       }*/
       /*char[] c={'d','a','l','l','a','s'};
       System.out.println(c);*/
       /*int s[] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
       int d[] = { 15, 25, 35, 45, 55, 65, 75, 85, 95, 105};
       System.arraycopy(s, 3, d, 5, 4);   
       // Print elements of destination after
           for (int i = 0; i < d.length; i++){
             System.out.print("final dest_array : ");
             System.out.print(d[i] + " ");}
             System.out.print("\n");*/
       
       /*int[] myLst={1,2,3,4};
       int sum=0;
       for (int i=0;i<myLst.length;i++) {
           sum+=myLst[i];
       }
       System.out.println("the sum after adding all the elements in the list is: "+sum);
       int largest=myLst[0];
       for (int i=0;i<myLst.length;i++) {
           if (largest<myLst[i])
               largest=myLst[i];
           
       }
       System.out.println("the largest element in the list is: "+largest);*/
//COPYING ARRAYS
//1-USING A LOOP
/*int[] array1={2,3,1,5,10};
int[] array2=new int[array1.length];
/*for (int i=0;i<array1.length;i++) 
    array2[i]=array1[i];
for (int i=0;i<array1.length;i++) 
    System.out.println(array2[i]+" ");*/
//2-ARRAYCOPY
/*System.arraycopy(array1,0,array2,0,5);
for (int i=0;i<array2.length;i++) 
    System.out.println(array2[i]+" ");*/
/*double sum=0,avg;
int count=0;
double[] array=new double[100];
for (int i=0;i<array.length;i++) {
    array[i]=Math.random()*100;
    sum+=array[i];
}
avg=sum/100;
for (int i=0;i<array.length;i++) {
    if (array[i]>avg)
        count++;
}
System.out.println("the average of 100 random numbers is: "+avg);
System.out.println(count+" numbers are above the average");*/
 /*int[] lst1;
 lst1=new int[5];
 for (int i=0;i<lst1.length;i++)
     lst1[i]=(int)(Math.random()*11);
/*int[] reversed=reverse(lst1);
System.out.println("LIST 1\t\tLIST2");
for (int i=0;i<lst1.length;i++) {
    
    System.out.println(lst1[i]+"\t\t"+reversed[i]);
}*/
/*System.out.print("["); 
for (int value:lst1)
    System.out.print(value+" ");
System.out.println("\b]");  */
//VarArgs();
//VarArgs(new String[]{"D","E","F","G"});
PrintMax();
PrintMax(34,3,56.5,2);
PrintMax(new double[]{1,5,2,3});







    }
    
    
    public static int[] reverse(int[] list) {
        int[] rev=new int[list.length];
        for (int i=0,j=list.length-1;i<list.length;i++,j--) 
          rev[j]=list[i];    
        return rev;
    } 
    public static void VarArgs(String...a) {
        System.out.println("number of arguments: "+a.length);
        for (String value:a)
            System.out.print(value+" ");
        System.out.println();
        
    }
    public static void PrintMax(double...numbers) {
        if (numbers.length==0){
            System.out.println("no argument passed");
        }
        else {
            double result=numbers[0];
        
        for (int i=1;i<numbers.length;i++) {
            if (numbers[i]>result)
                result=numbers[i];
    }
    System.out.println(result);
    }
    }
    
    
    
    
    
    
    
    
}
