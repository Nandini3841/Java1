/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter8code;

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Chapter8Code {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*//CREATING 2D LISTS
        //1
        int[][] dupList;
        dupList=new int[3][3];
        //2
        int[][]dupList1=new int[3][3];
        //3
        int[][]dupList2={
            {1,2,3},
            {4,5,6}
        };*/
        
        /*int[][]array={
            {1,2,3},
            {4,5,6},
            {7,8,9},
            {10,11,12}
                
        };
        
        int [][] array1=new int[4][3];
        array1[0][0]=1;array1[0][1]=2;array1[0][2]=3;
        array1[1][0]=4;array1[1][1]=5;array1[1][2]=6;
        array1[2][0]=7;array1[2][1]=8;array1[2][2]=9;
        array1[3][0]=10;array1[3][1]=11;array1[3][2]=12;
        
        for (int i=0;i<array1.length;i++) {
            for (int j=0;j<array1.length-1;j++) {
              System.out.println(array1[i][j]);
        }
        }
        System.out.println(array1.length);
        System.out.println(array1[0].length);
        System.out.println(array1[1].length);
        System.out.println(array1[2].length);
        System.out.println(array1[3].length);*/
        
        //RAGGED ARRAYS
        int[][] triArray={
            {1,2,3,4,5},
            {2,3,4,5},
            {3,4,5},
            {4,5},
            {5}
        };
        /*for (int i=0;i<triArray.length;i++){
            for (int j=0;j<triArray[i].length;j++) {
                System.out.println(triArray[i][j]+" ");
            }
            System.out.println();
        }*/
        /*//INITIALIZING ARRAYS WITH INPUT VALUES
        Scanner input=new Scanner(System.in);
        System.out.print("enter the length of row:");
        int row=input.nextInt();
        System.out.print("enter the length of column:");
        int column=input.nextInt();
        double[][] inputLst=new double[row][column];
        for (int i=0;i<inputLst.length;i++) {
            for (int j=0;j<inputLst[i].length;j++) {
                System.out.print("element"+"["+i+"]"+"["+j+"]:");
                inputLst[i][j]=input.nextInt();
                
            }
            System.out.println("the list after entering the elements is:");
            for (int k=0;k<inputLst.length;k++) {
            for (int j=0;j<inputLst[i].length;j++) {
                System.out.print("element"+"["+k+"]"+"["+j+"]:");
                System.out.println(inputLst[k][j]);
                
            }
        }*/
            //PRINTING ARRAYS
            //DONE 
            
            /*//SUMMING ALL ELEMENTS
            int sum=0;
            for (int i=0;i<triArray.length;i++) {
                for (int j=0;j<triArray[i].length;j++) {
                    sum+=triArray[i][j];
                }
            
    }
    System.out.println("the sum is:"+sum);
    }*/
    //SUMMING ELEMENTS BY  COLUMN
     int sumC=0;
            for (int i=0;i<triArray.length;i++) {
                for (int j=0;j<triArray[i].length;j++) {
                    sumC+=triArray[i][j];
                
                }
                System.out.println("the sum of column "+(i+1)+" is:"+sumC);
                sumC=0;
    }
    //System.out.println("the sum is:"+sumC);
    }
    
    
    
    
}
