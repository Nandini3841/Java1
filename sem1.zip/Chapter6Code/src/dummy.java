/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
 String creds(String name,String pass) {
  System.out.print("USERNAME:");
  
}

public class dummy {
    public static void main(String args[]) {
        Scanner input=new Scanner(System.in);
        
        
        
        
        
    }   
}


  
  


