/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter6code;

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Dummy {
    public static int max(int i1,int i2) {
        int result;
        if (i1>i2) result=i1;
        else result=i2;
        return result;
            
        }
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("enter the first number:");
        int num1=input.nextInt();
        System.out.print("enter the second number:");
        int num2=input.nextInt();
        System.out.println("the greater number is:"+max(num1,num2));
        
    }
    
        
    
    
}
