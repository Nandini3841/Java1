/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter6code;

/**
 *
 * @author user
 */
public class Chapter6Code {
    public static int sum(int i1,int i2) {
        int sum=0;
        for (int i=i1;i<=i2;i++) {
            sum+=i;
        }
        return sum;
        
    }
    public static void ret(int n) {
        n=2;
        System.out.println("in function call:"+n);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*System.out.println("creating a summation method"+"\n");
        System.out.println("sum from 35 to 45:"+sum(35,45));
        System.out.println("sum from 20 to 30:"+sum(20,30));
        System.out.println("sum from 1 to 10:"+sum(1,10));*/
        /*int num=1;
        System.out.println("before function call:"+num);
        ret(num);
        System.out.println("after function call:"+num);*/
        System.out.println("           Multiplication Table");

    // Display the number title
    System.out.print("    ");
    for (int j = 1; j <= 9; j++)
      System.out.print("   " + j);

    System.out.println("\n-----------------------------------------");

    // Print table body
    for (int i = 1; i <= 9; i++) {
      System.out.print(i + " | ");
      for (int j = 1; j <= 9; j++) {
        // Display the product and align properly
        System.out.printf("%4d", i * j);
        
      }   
        
    }    
        
    }        
        
        
    
    
}
