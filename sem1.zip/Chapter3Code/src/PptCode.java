/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class PptCode {
    public static void main(String[] args) {
        //1
        Scanner input=new Scanner(System.in);
        /*System.out.println("this is a program to create a simple math tool");
        int num1=(int)(Math.random()*10);
        int num2=(int)(Math.random()*10);
        int sum=num1+num2;
        System.out.print("What is "+num1+"+"+num2+"?");
        int sum1=input.nextInt();
        if (sum==sum1) {
            System.out.println("CORRECT!");
            
        }
        else {
            System.out.println("WRONG!\nThe correct answer is "+sum);
        
        
        int time=20;
        
        
        
        
        
        }*/
        
        //2
        /*System.out.println("this is a program to check divisibility by 5 and 2");
        System.out.print("enter the number here:");
        int num=input.nextInt();
                   

        if (num%2==0 && num%5==0) {
            System.out.println("hievenhiodd");
        }
        else if (num%2==0) {
            System.out.println("HiEven!");
        }
        else if (num%5==0) {
            System.out.println("HiFive!");   
        }
        else {
            System.out.println("neither divisible by 2 nor 5");
        }*/
        
        //System.out.println("this is a programming tool to teach a child about subtraction");
        //int num1=(int)(Math.random()*10);
        //int num2=(int)(Math.random()*10);
        /*if (num1>num2) {
            int difference=num1-num2;
            System.out.print("what is "+num1+"-"+num2+"?");
            int ans=input.nextInt();
            if (ans==difference) {
              System.out.println("CORRECT!");
            }
            else {
            System.out.println("WRONG!\nThe correct answer is "+difference);
            }  
            
        }
        else {
            int difference=num2-num1;
            System.out.print("what is "+num1+"-"+num2+"?");
            int ans=input.nextInt();
            if (ans==difference) {
              System.out.println("CORRECT!");
            }
            else {
            System.out.println("WRONG!\nThe correct answer is "+difference);x
        
        
        
            }*/
        /*if (num1<num2) {
            int temp=num1;
            num1=num2;
            num2=temp;
        }
        System.out.print("what is "+num1+"-"+num2+"?");
        int ans=input.nextInt();
        if (ans==(num1-num2)) {
            System.out.println("CORRECT!");
        }
        else {
            System.out.println("WRONG!\nThe answer is "+(num1-num2));
        }  */
        
        //System.out.print(60&30); 
        /*System.out.println("This is a program to determine leap year");
        System.out.print("enter here:");
        int year=input.nextShort();
        if (year%4==0 && year%100!=0 || year%400==0) {
            System.out.println("LEAP YEAR");
        }
        else {
            System.out.println("NOT A LEAP YEAR");
        }*/
        /*System.out.println("executing switch");
        System.out.println("Press '0' for calculating tax for single filers\nPress '1' for calculating tax for married jointly or qualifying widow\nPress '2' for calculating tax for married filing separately\nPress '3' for calculating tax for head of household\n");
        System.out.print("enter here:");
        int ch=input.nextInt();
        switch(ch) {
            case 1:System.out.println('n');break;
            case 2:System.out.println('a');break;
            case 3:System.out.println('n');break;
            default:System.out.println("SORRY!INVALID DIGIT ENTERED");*/
        
        /*int time=20;
        if (time>18) {
            System.out.println("Good evening!");
        }
        else {
            System.out.println("good day!");*/
        
        
        /*System.out.println("this is a program to teach a child subtraction");
        int int1=(int)(Math.random()*10);
        int int2=(int)(Math.random()*10);
        if (int1<int2) {
            int temp=int1;
            int1=int2;
            int2=temp;
        }    
        System.out.printf("%d-%d=",int1,int2);
        int ans=input.nextInt();
        if (ans==(int1-int2)) {
            System.out.println("CORRECT!");
        }    
        else {
            System.out.println("WRONG!\n THE CORRECT ANSWER IS "+(int1-int2));*/
        /*int a=60;
        int b=13;
        System.out.println(a&b);
        System.out.println(a|b);
        System.out.println(a^b);*/
        /*System.out.println("this is a program to print the BMI and compute whether you are underweight,normal,overweight or obese");
        System.out.print("enter your weight here:");
        double wt=input.nextDouble();
        System.out.println("enter your height in metres");
        double ht=input.nextDouble();
        double Bmi=(wt/(ht*ht));
        if (Bmi<18.5) {
            System.out.println("UNDERWEIGHT");
        }
        else if (Bmi>=18.5 && Bmi<25.0) {
            System.out.println("NORMAL");
        }
        else if (Bmi>=25.0 && Bmi<30.0) {
            System.out.println("OVERWEIGHT");
        }  
        else {
            System.out.println("OBESE");*/
        
        
        //System.out.printf("%10s%10s%n","Name","Age");
        //System.out.printf("%10s%10d%n%10s%10d%n","Nandini",18,"jolly rancher",87);
       // System.out.println((char)4));
       
        //int i=120.0;
        /*Character x = new Character('a');
        System.out.println(x);*/
        //String s="java";
        //ystem.out.println(s.indexOf('u'));
        //char c=s[0];
        //System.out.printf("%8d",123456);
         /*System.out.println("ADDITION QUIZ");
         int num1,num2,sum;
         num1=(int)(Math.random()*10);   
         num2=(int)(Math.random()*10);   
         sum=num1+num2;
         System.out.print(num1+"+"+num2+"=");
         int guess=input.nextInt();
        if (guess==sum) {
            System.out.println("CORRECT");
        }
        else {
            System.out.println("WRONG! THE CORRECT ANSWER IS: "+sum);*/
        /*System.out.println("THIS IS A PROGRAM TO CHECK WHETHER A NUMBER IS DIVISIBLE BY 5,2");
        System.out.print("enter the number as integer:");
        int num=input.nextInt();
        if (num%5==0)
            System.out.println("HiFive");
        else if(num%2==0)
            System.out.println("HiEven");
        else if(num%2==0 && num%5==0) 
            System.out.println("HiFiveHiEven");
        else 
            System.out.println("neither divisible by 2 nor 5");*/
        /*System.out.println("SUBTRACTION QUIZ");
        int num1,num2,diff,guess;
        num1=(int)(Math.random()*10);
        num2=(int)(Math.random()*10);
        
        if (num1>num2) {
            System.out.print(num1+"-"+num2+"=");
            guess=input.nextInt();
            diff=num1-num2;
            if (diff==guess)
                System.out.println("correct");
            else 
                System.out.println("wrong. the correct answer is: "+diff);
        }
        else {
            System.out.print(num2+"-"+num1+"=");
            guess=input.nextInt();
            diff=num2-num1;
            if (diff==guess)
                System.out.println("correct");
            else 
                System.out.println("wrong. the correct answer is: "+diff);
        }*/
        /*System.out.println("LEAP YEAR");
            System.out.print("enter the year: ");
            int year=input.nextInt();
            if (((year%4==0) && !(year%100==0))||(year%400==0)) {
                System.out.println(year+" is a leap year");
            }
            else 
                System.out.println(year+" is not a leap year");*/
        
        
        
        
        
        
        
        
            
                    
        
        
        
        
        
        
        
            
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                
    }  
    
        
                
              
        
        
        
        
    
}   